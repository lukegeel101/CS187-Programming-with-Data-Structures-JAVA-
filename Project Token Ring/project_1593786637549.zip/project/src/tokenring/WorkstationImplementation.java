package tokenring;


public class WorkstationImplementation extends Workstation {

  public WorkstationImplementation(NetworkInterface nic) {
    // TODO: Implement the WorkstationImplementation constructor
  }

  public NetworkInterface getNIC() {
    // TODO: Implement the getNic() method
    return null;
  }

  @Override
  public int compareTo(Workstation o) {
    // TODO: Implement the compareTo() method
    return 0;
  }

  @Override
  public boolean equals(Object obj) {
    // TODO: Implement the equals() method
    return false;
  }

  public void sendMessage(Message m) {
    // TODO: Implement the sendMessage() method
  }

  @Override
  public void tick() {
    // TODO: Implement the tick() method
  }
}
