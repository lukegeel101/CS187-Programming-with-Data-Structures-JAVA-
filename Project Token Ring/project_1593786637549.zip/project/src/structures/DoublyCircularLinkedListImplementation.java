package structures;

public class DoublyCircularLinkedListImplementation<T extends Comparable<T>>
    implements DoublyCircularLinkedList<T> {

  public DoublyCircularLinkedListImplementation() {
    // TODO: implement the constructor
  }

  @Override
  public int size() {
    // TODO: implement the size method.
    return size();
  }

  @Override
  public void add(T element) {
    // TODO: Implement the add method!
  }

  @Override
  public boolean remove(T element) {
    // TODO: implemement the remove method!
    return false;
  }


  @Override
  public boolean contains(T element) {
    // TODO: Implement the contains() method
    return false;
  }

  @Override
  public T get(T element) {
    // TODO: Implement the get() method
    return null;
  }

  @Override
  public void reset() {
    // TODO: Implement the reset() method
  }

  @Override
  public T getNext() {
    // TODO: Implement the getNext() method
    return null;
  }

  @Override
  public T getPrevious() {
    // TODO: Implement the getPrevious() method
    return null;
  }
}
