package structures;

public class DoublyCircularLinkedListImplementation<T extends Comparable<T>>
    implements DoublyCircularLinkedList<T> {
      private int listSize;
      private DLLNode<T> list;
      private DLLNode<T> location;
      private DLLNode<T> previous;
      private DLLNode<T> currentPos;
      private boolean found;

  public DoublyCircularLinkedListImplementation() {
    listSize = 0;
		list = null;
		location = null;
		previous = null;
		currentPos = null;
		found = false;
  }

  @Override
  public int size() {
    // TODO: implement the size method.
    return listSize;
  }

  @Override
  public void add(T element) {
    // TODO: Implement the add method!
    DLLNode<T> newNode = new DLLNode<T>(element);
		if (list == null){
			list = newNode;
			newNode.setForward(list);
			newNode.setBack(list);
		}
		else{
			newNode.setForward(list);
			newNode.setBack(list.getBack());
			list.getBack().setForward(newNode);
			list.setBack(newNode);
		}
		listSize++;
  }

  @Override
  public boolean remove(T element) {
    // TODO: implemement the remove method!
    return false;
  }


  @Override
  public boolean contains(T element) {
    // TODO: Implement the contains() method
    return found;
  }

  @Override
  public T get(T element) {
    // TODO: Implement the get() method
    return location.getInfo();
  }

  @Override
  public void reset() {
    // TODO: Implement the reset() method
    currentPos = list;
  }

  @Override
  public T getNext() {
    // TODO: Implement the getNext() method
    if(currentPos == null){
			return null;
		}
		else{
			T nextElem = currentPos.getInfo();
			currentPos = currentPos.getForward();
			return nextElem;
		}
  }

  @Override
  public T getPrevious() {
    // TODO: Implement the getPrevious() method
    if(currentPos == null){
			return null;
		}
		else{
			T prevElem = currentPos.getBack().getInfo();
			currentPos = currentPos.getBack();
			return prevElem;
		}
  }
}
