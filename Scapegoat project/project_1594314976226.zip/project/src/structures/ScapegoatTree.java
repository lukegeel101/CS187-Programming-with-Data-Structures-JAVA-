package structures;

public class ScapegoatTree<T extends Comparable<T>> extends
		BinarySearchTree<T> {

	private int upperBound;
	

	@Override
	public void add(T element) {
		upperBound++;
		double LogLim = Math.log10(upperBound) / Math.log10(3/2);
		if (LogLim < upperBound){
			
		}
  }

	@Override
	public boolean remove(T t) {
		// TODO
		if (t == null) {
			throw new NullPointerException();
		}
		boolean result = contains(t);
		if (result) {
		//	root = removeFromSubtree(root, t);
		}
		if (upperBound > 2*size()) {
			balance();
			upperBound = size();
		}
		return result;
	}

}