package structures;

public class ScapegoatTree<T extends Comparable<T>> extends BinarySearchTree<T> {
  private int upperBound;


  @Override
  public void add(T t) {
    // TODO: Implement the add() method
  }

  @Override
  public boolean remove(T element) {
    // TODO: Implement the remove() method
    return false;
  }
}
