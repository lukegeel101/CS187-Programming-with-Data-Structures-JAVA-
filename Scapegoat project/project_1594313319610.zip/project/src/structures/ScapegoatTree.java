package structures;

public class ScapegoatTree<T extends Comparable<T>> extends
		BinarySearchTree<T> {

	private int upperBound;
	

	@Override
	public void add(T element) {
		upperBound++;
		double LogLim = Math.log10(upperBound) / Math.log10(3/2);
		if (LogLim < upperBound){
			
		}
  }

	@Override
	public boolean remove(T element) {
		// TODO
		return false;
	}

}