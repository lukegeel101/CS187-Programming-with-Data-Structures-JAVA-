package sorting;

import structures.Queue;

/**
 * A class containing methods to sort queues and merge sorted queues.
 *
 * <p>"Sorted" means in ascending order: the front of the queue is the smallest element, and the
 * rear of the queue is the largest.
 *
 * <p>e1 is less than or equal to e2 if and only if (e1.compareTo(e2) <= 0)
 *
 * <p>You may not use loops (for, while, do, etc.) in this class. You must instead use recursion.
 */
public class MergeSorter<T extends Comparable<T>> {
  /**
   * Returns a new queue containing the elements from the input queue in sorted order.
   *
   * <p>Do not modify the input queue! Work on a copy of the input.
   *
   * <p>Implement this method recursively:
   *
   * <p>In the base case, return the sorted queue.
   *
   * <p>Otherwise:
   *
   * <p>First, divide the input queue into two smaller output queues.
   *
   * <p>Then, recursively mergeSort each of these smaller queues.
   *
   * <p>Finally, return the result of merging these two queues.
   *
   * @param queue an input queue
   * @return a sorted copy of the input queue
   */
  public Queue<T> mergeSort(Queue<T> queue) {
    // TODO implement the mergeSort method
    return null;
  }

  /**
   * Places elements from the input queue into the output queues, roughly half and half.
   *
   * <p>Implement this method recursively:
   *
   * <p>In the base case, there's nothing left to do.
   *
   * <p>Otherwise:
   *
   * <p>Make progress on moving elements from the input to the output.
   *
   * <p>Then make a recursive call to divide.
   *
   * @param input a queue
   * @param output1 a queue into which about half of the elements in input should go
   * @param output2 a queue into which the other half of the elements in input should go
   */
  public void divide(Queue<T> input, Queue<T> output1, Queue<T> output2) {
    // TODO implement the divide method
  }

  /**
   * Merges sorted input queues into an output queue in sorted order, and returns that queue.
   *
   * <p>Use mergeHelper to accomplish this goal.
   *
   * @param input1 a sorted queue
   * @param input2 a sorted queue
   * @return a sorted queue consisting of all elements from input1 and input2
   */
  public Queue<T> merge(Queue<T> input1, Queue<T> input2) {
    // TODO implement the merge method
    return null;
  }

  /**
   * Merges the sorted input queues into the output queue in sorted order.
   *
   * <p>Implement this method recursively:
   *
   * <p>In the base case, there's nothing left to do.
   *
   * <p>Otherwise:
   *
   * <p>Make progress on moving elements from an input to the output.
   *
   * <p>Then make a recursive call to mergeHelper.
   *
   * @param input1 a sorted queue
   * @param input2 a sorted queue
   * @param output a sorted queue containing the accumulated progress so far
   */
  void mergeHelper(Queue<T> input1, Queue<T> input2, Queue<T> output) {
    // TODO implement the mergeHelper method
  }
}
