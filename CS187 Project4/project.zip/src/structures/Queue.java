package structures;

import java.util.NoSuchElementException;

public class Queue<T> implements UnboundedQueueInterface<T> {

  public Queue() {
    // TODO implement the constructor
  }

  public Queue(Queue<T> other) {
    // TODO implement another constructor
  }

  @Override
  public boolean isEmpty() {
    // TODO implement the isEmpty method
    return false;
  }

  @Override
  public int size() {
    // TODO implement the size method
    return 0;
  }

  @Override
  public void enqueue(T element) {
    // TODO implement the enqueue method
  }

  @Override
  public T dequeue() throws NoSuchElementException {
    // TODO implement the dequeue method
    return null;
  }

  @Override
  public T peek() throws NoSuchElementException {
    // TODO implement the peek method
    return null;
  }

  @Override
  public UnboundedQueueInterface<T> reversed() {
    // TODO implement the reversed method
    return null;
  }
}
