package filesystem;

import java.util.Iterator;

public abstract class FileIterator<T> implements Iterator<T> {}
